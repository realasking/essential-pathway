changlog
--------
2017-08-23 Modified ep to keep module file epath unloaded before ep start.
2017-08-15 Finished debuging and testing in 64bit linux, and publish version 1.0 
2017-08-06 All scripts have been rewritten by using python3
2017-07-23 Begins to arrange older scripts I wrote to manage massive folders' paths
