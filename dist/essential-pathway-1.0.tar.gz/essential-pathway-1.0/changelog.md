changlog
--------
2017-07-23 Begins to arrange older scripts I wrote to manage massive folders' paths
2017-08-06 All scripts have been rewritten by using python3
2017-08-15 Finished debuging and testing in 64bit linux, and publish version 1.0 
